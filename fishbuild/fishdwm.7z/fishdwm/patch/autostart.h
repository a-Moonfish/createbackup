static void runautostart(void);
