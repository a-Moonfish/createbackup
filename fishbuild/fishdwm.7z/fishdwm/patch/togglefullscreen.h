static void togglefullscreen(const Arg *arg);
