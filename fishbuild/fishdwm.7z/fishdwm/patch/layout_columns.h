static void col(Monitor *);
